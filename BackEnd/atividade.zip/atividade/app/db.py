from sqlalchemy import create_engine

engine = create_engine(
    "postgresql+psycopg2://postgres:univassouras@db:5432/atividade",
    echo=True
)